﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadanie
{
    public interface DzialanieMatematyczne
    {
        int Dodaj(int a, int b);
        int Odejmij(int a, int b);
        int Pomnoz(int a, int b);
        int Podziel(int a, int b);
    }

    public interface Logowanie
    {
        void Zaloguj(string nazwaUzytkownika, string haslo);
        void Wyloguj();
    }

    public interface Statystyki
    {
        double Srednia(List<int> liczby);
        int Mediana(List<int> liczby);
        int Moda(List<int> liczby);
    }

    public class ZaawansowanyKalkulator : DzialanieMatematyczne, Logowanie, Statystyki
    {
        public int Dodaj(int a, int b)
        {
            return a + b;
        }

        public int Odejmij(int a, int b)
        {
            return a - b;
        }

        public int Pomnoz(int a, int b)
        {
            return a * b;
        }

        public int Podziel(int a, int b)
        {
            if (b == 0)
            {
                throw new DivideByZeroException();
            }
            return a / b;
        }

        public void Zaloguj(string nazwaUzytkownika, string haslo)
        {
            
        }

        public void Wyloguj()
        {
            
        }

        public double Srednia(List<int> liczby)
        {
            return liczby.Average();
        }

        public int Mediana(List<int> liczby)
        {
            var posortowaneLiczby = new List<int>(liczby);
            posortowaneLiczby.Sort();

            int liczbaElementow = posortowaneLiczby.Count;
            if (liczbaElementow % 2 == 1)
            {
                return posortowaneLiczby[liczbaElementow / 2];
            }
            else
            {
                return (posortowaneLiczby[(liczbaElementow / 2) - 1] + posortowaneLiczby[liczbaElementow / 2]) / 2;
            }
        }

        public int Moda(List<int> liczby)
        {
            var grupy = liczby.GroupBy(i => i);
            var najczestszaGrupa = grupy.OrderByDescending(g => g.Count()).First();
            return najczestszaGrupa.Key;
        }
    }
}
