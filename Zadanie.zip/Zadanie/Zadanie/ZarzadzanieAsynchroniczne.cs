﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadanie
{
    public interface ZarzadzanieAsynchroniczne
    {
        Task WykonajAkcjeAsynchronicznie();
        Task PobierzDaneAsynchronicznie();
    }

    public class ImplementacjaAsynchroniczna : ZarzadzanieAsynchroniczne
    {
        public async Task WykonajAkcjeAsynchronicznie()
        {
            await Task.Delay(1000);
            Console.WriteLine("odpalanie");
        }

        public async Task PobierzDaneAsynchronicznie()
        {
            await Task.Delay(1000);
            Console.WriteLine("dane pobrane");
        }
    }
}
