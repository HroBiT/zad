﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadanie
{
    public interface Dzwiek
    {
        void OdtwarzajDzwiek();
    }

    public class Samochod : Dzwiek
    {
        public void OdtwarzajDzwiek()
        {
            Console.WriteLine("brum brum");
        }
    }

    public class Telefon : Dzwiek
    {
        public void OdtwarzajDzwiek()
        {
            // Implementacja metody
            Console.WriteLine("dring dring");
        }
    }



}
