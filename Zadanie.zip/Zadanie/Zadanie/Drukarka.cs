﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadanie
{
    public interface Drukarka
    {
        void Drukuj();
    }

    public class DrukarkaLaserowa : Drukarka
    {
        void Drukarka.Drukuj()
        {
            Console.WriteLine("Drukuj zaimplementowany niejawnie");
        }

        public void Drukuj()
        {
            Console.WriteLine("Drukuj zaimplementowany jawnie");
        }
    }

}
