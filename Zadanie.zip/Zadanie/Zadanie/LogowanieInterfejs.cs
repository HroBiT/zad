﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadanie
{
    public interface LogowanieInterfejs
    {
        bool Loguj(string username, string password);
    }

    public static class LogowanieExtensions
    {
        public static bool Loguj(this LogowanieInterfejs logowanie, string username, string password)
        {
            // Domyślna nazwa użytkownika i hasło
            const string defaultUsername = "123";
            const string defaultPassword = "123";

            // Sprawdź, czy podane hasło jest poprawne
            if (username == defaultUsername && password == defaultPassword)
            {
                Console.WriteLine("Użytkownik zalogowany.");
                return true;
            }
            else
            {
                Console.WriteLine("Niepoprawne hasło.");
                return false;
            }
        }
    }

    public class Uzytkownik : LogowanieInterfejs
    {
        // Domyślna nazwa użytkownika i hasło
        const string defaultUsername = "123";
        const string defaultPassword = "123";

        // Implementacja metody Loguj
        public bool Loguj(string username, string password)
        {
            // Sprawdź, czy podane hasło jest poprawne
            if (username == defaultUsername && password == defaultPassword)
            {
                Console.WriteLine("Użytkownik zalogowany.");
                return true;
            }
            else
            {
                Console.WriteLine("Niepoprawne hasło.");
                return false;
            }
        }
    }
}
