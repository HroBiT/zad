﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadanie
{
    class Program
    {
        static void Main(string[] args)
        {
            // Zadanie 1
            Kalkulator prostyKalkulator = new ProstyKalkulator();
            Console.WriteLine("Dodawanie");
            Console.WriteLine(prostyKalkulator.Dodaj(5, 3));
            Console.WriteLine("odejmowanie");
            Console.WriteLine(prostyKalkulator.Odejmij(5, 3));
            Console.WriteLine("\n");
            // Zadanie 2
            ZaawansowanyKalkulator zaawansowanyKalkulator = new ZaawansowanyKalkulator();
            zaawansowanyKalkulator.Zaloguj("user", "password");
            Console.WriteLine("Dodawanie");
            Console.WriteLine(zaawansowanyKalkulator.Dodaj(10, 5));
            Console.WriteLine("odejmowanie");
            Console.WriteLine(zaawansowanyKalkulator.Odejmij(10, 5));
            Console.WriteLine("mnozenie");
            Console.WriteLine(zaawansowanyKalkulator.Pomnoz(10, 5));
            Console.WriteLine("dzielenie");
            Console.WriteLine(zaawansowanyKalkulator.Podziel(10, 5));
            zaawansowanyKalkulator.Wyloguj();
            Console.WriteLine("\n");
            // Zadanie 3
            Console.WriteLine("drukowanie");
            Drukarka drukarka = new DrukarkaLaserowa();
            drukarka.Drukuj();
            Console.WriteLine("\n");
            // Zadanie 4
            Console.WriteLine("dzwiek");
            List<Dzwiek> dzwieki = new List<Dzwiek> { new Samochod(), new Telefon() };
            foreach (var dzwiek in dzwieki)
            {
                dzwiek.OdtwarzajDzwiek();
            }
            Console.WriteLine("\n");
            // Zadanie 5
            Console.Write("Wprowadź nazwę użytkownika: ");
            string username = Console.ReadLine();

            Console.Write("Wprowadź hasło: ");
            string password = Console.ReadLine();

            Uzytkownik uzytkownik = new Uzytkownik();
            uzytkownik.Loguj(username, password);

            Console.ReadKey();
            Console.WriteLine("\n");
            // Zadanie 6
            Console.WriteLine("repozytorium");
            IRepozytorium<int> repozytorium = new Repozytorium<int>();
            repozytorium.Dodaj(5);
            Console.WriteLine(repozytorium.Pobierz(0));
            repozytorium.Aktualizuj(10);
            repozytorium.Usun(10);
            Console.WriteLine("\n");
            // Zadanie 7
            Console.WriteLine("Asynchroiczne zarzadzanie");
            ZarzadzanieAsynchroniczne zarzadzanieAsynchroniczne = new ImplementacjaAsynchroniczna();
            zarzadzanieAsynchroniczne.WykonajAkcjeAsynchronicznie().Wait();
            zarzadzanieAsynchroniczne.PobierzDaneAsynchronicznie().Wait();

            Console.ReadKey();
        }
    }
}
