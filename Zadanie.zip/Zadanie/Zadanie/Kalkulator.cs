﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadanie
{
    public interface Kalkulator
    {
        int Dodaj(int a, int b);
        int Odejmij(int a, int b);
    }

}
