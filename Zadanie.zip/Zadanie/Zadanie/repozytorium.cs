﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadanie
{
    public interface IRepozytorium<T>
    {
        void Dodaj(T item);
        T Pobierz(int id);
        void Aktualizuj(T item);
        void Usun(T item);
    }

    public class Repozytorium<T> : IRepozytorium<T>
    {
        private List<T> kolekcja = new List<T>();

        public void Dodaj(T item)
        {
            // Implement the method
            kolekcja.Add(item);
        }

        public T Pobierz(int id)
        {
            // Implement the method
            return kolekcja[id];
        }

        public void Aktualizuj(T item)
        {
            // Implement the method
            int index = kolekcja.IndexOf(item);
            if (index != -1)
            {
                kolekcja[index] = item;
            }
        }

        public void Usun(T item) 
        {
            // Implement the method
            kolekcja.Remove(item);
        }
    }
}
