﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zadanie
{
    public class ProstyKalkulator : Kalkulator
    {
        public int Dodaj(int a, int b)
        {
            return a + b;
        }

        public int Odejmij(int a, int b)
        {
            return a - b;
        }
    }
}
